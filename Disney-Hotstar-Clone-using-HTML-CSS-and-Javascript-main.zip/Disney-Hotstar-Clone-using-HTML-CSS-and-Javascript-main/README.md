# Disney-Hotstar-Clone-using-HTML-CSS-and-Javascript
This is the clone of Disney+ hotstar made using html, css and javascript only.
Link - https://8yc0cs.csb.app/
